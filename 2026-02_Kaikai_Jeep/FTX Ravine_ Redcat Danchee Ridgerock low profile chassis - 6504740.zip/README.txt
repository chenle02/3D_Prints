FTX Ravine/ Redcat Danchee Ridgerock low profile chassis by danjr1 on Thingiverse: https://www.thingiverse.com/thing:6504740

Summary:
An alternative chassis for the FTX Ravine/ Redcat Danchee Ridgerock. Print the two chassis plates, one skid plate and two spacers. I've used m3 button head 20mm bolts to put it all together, with 10mm m3 button head bolts for the standard side skids but these are optional.You may need to drill out some holes but you don't need to tap anything. The plastic-cutting screws that come standard with these cars should also work but don't drill out any holes if you do.